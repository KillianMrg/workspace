from django.contrib import admin
from appli.models import UserProfileInfo, User

# Register your models here.
admin.site.register(UserProfileInfo)