from django.apps import AppConfig


class AppliConfig(AppConfig):
    name = 'appli'
